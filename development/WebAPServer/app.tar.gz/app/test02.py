import psycopg2
import sys
import os

fileName = os.system("ls -1t *02_Upload.txt| head -n1")
try:
    cnn = psycopg2.connect("dbname=enpit host=52.33.44.1 user=vagrant password=enpit")
    cur = cnn.cursor()
    sensor_id = '00000001'
    str_timestamp = '20151212115000'
    str_year = '2015'
    str_mon = '12'
    str_day = '12'
    str_hh  = '11' 
    value   = '00000055'
    ivalue  = '55'
    timestamp = 'current_timestamp'    
    target_sensor = '00000001'
    target_mon = '12'

    print("INSERT INSERT ==========================")
    cur.execute(u"""INSERT INTO tbl20001_sensor_data(SENSOR_ID, STR_TIMESTAMP,STR_YEAR,STR_MON,STR_DAY,STR_HH,VALUE,IVALUE)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s )""" , (sensor_id, str_timestamp, str_year, str_mon, str_day, str_hh,value,ivalue,))

    cnn.commit()
    cur.execute("""SELECT *  FROM tbl20001_sensor_data  
                WHERE SENSOR_ID = %s AND  str_mon =%s""" , (target_sensor, target_mon, ))
    rows = cur.fetchall()
    for row in rows:
        #print("%d %s" % (row[0],unicode(row[1],'utf-8')))
        print("%s %s" % (row[0],row[1]))
    cnn.commit()

    cur.close()
    cnn.close()

except (psycopg2.OperationalError) as e:
    print (e)
