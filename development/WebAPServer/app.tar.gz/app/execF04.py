import sys
import glob
import os
from Dao import Dao
from ftest import ftest 
import psycopg2

#Directory Read 
SENSOR_PATH = '/var/sensor/04/*.txt'
files = glob.glob(SENSOR_PATH) 
files.sort()

ft = ftest()
for file in files:
    ft.readData(file)
os.system("mv /var/sensor/04/*.txt /var/sensor/BKUP/04/")
print 'complete'

