import psycopg2
from Query import Query

class Dao:
    def __init__(self):
        #query = ''
        cnn = psycopg2.connect("dbname=enpit host=52.33.44.1 user=vagrant password=enpit")
        cur = cnn.cursor()
        self.q1 = Query()
        self.cnn = cnn
        self.cur = cur

    def close(self,cur,cnn):
        cur.close()
        cnn.close()

    # For QueryParameter 1 
    def load01(self, index, para1):
        result = {}
        self.query = self.q1.getQueryStr(index)
        self.cur.execute(""+self.query+"", (para1,))
        rows = self.cur.fetchall()
        self.close(self.cur,self.cnn)
        return rows

    # For QueryParameter 2
    def load02(self, index, para1, para2):
        result = {}
        self.query = self.q1.getQueryStr(index)
        self.cur.execute(""+self.query+"", (para1, para2, ))
        rows = self.cur.fetchall()
        self.close(self.cur,self.cnn)
        return rows

    # For QueryParameter 3 
    def load03(self, index, para1, para2, para3):
        result = {}
        self.query = self.q1.getQueryStr(index)
        self.cur.execute(""+self.query+"", (para1, para2, para3))
        rows = self.cur.fetchall()
        self.close(self.cur,self.cnn)
        return rows

    # For QueryParameter 4 
    def load04(self, index, para1, para2, para3, para4):
        result = {}
        self.query = self.q1.getQueryStr(index)
        self.cur.execute(""+self.query+"", (para1, para2, para3, para4))
        rows = self.cur.fetchall()
        self.close(self.cur,self.cnn)
        return rows

    # For Insert
    def InsertSensorData(self,sensorData,sensorID):
        print '+++++'+sensorData
        sensor_id = sensorID
        str_wk = sensorData.split(',')
        str_timestamp = str_wk[1] + '00' 
        str_value = str_wk[2] 

        print '+++++'+str_timestamp

        #value2  = str_wk[2]
        #ivalue2 = int(str_wk[2])
        #str_ivalue2 = str(int(value2))

        #print '+++++'+str_ivalue2

        #timestamp
        str_year = str_timestamp[0:4] 
        #year
        str_mon  = str_timestamp[4:6]
        #mon
        str_day  = str_timestamp[6:8]
        #str_day  = '05'
        str_hh   = str_timestamp[8:10]
        #hh
        value   = str_value[0:8]
        #value
        print '*******value*******' +value

        ivalue  = int(str_wk[2])
        timestamp = 'current_timestamp'
        target_sensor = sensorID 

        print '*******' + sensor_id + ',' + str_timestamp  + ',' +  str_year  + ',' + str_mon  + ',' + str_day  + ',' + str_hh  + ',' + value  + ',' + str(ivalue)
        print("INSERT INSERT ==========================")

        self.cur.execute(u"""INSERT INTO tbl20001_sensor_data(SENSOR_ID, STR_TIMESTAMP,STR_YEAR,STR_MON,STR_DAY,STR_HH,VALUE,IVALUE)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s )""" , (sensor_id, str_timestamp, str_year, str_mon, str_day, str_hh,value,ivalue,))

        self.cnn.commit()
        self.close(self.cur,self.cnn)
        print sensorID
        print 'CALL!'
    #except (psycopg2.OperationalError) as e:
    #    print (e)
