import sys

# Configure Query String Class 

class Query:
    def __init__(self):
        self.queryStr  = '' 
        self.queryList = [ "SELECT SENSOR_ID,VALUE,IVALUE,STR_TIMESTAMP FROM TBL20001_SENSOR_DATA  WHERE SENSOR_ID = %s", 
                      "SELECT SENSOR_ID,VALUE,IVALUE,STR_TIMESTAMP FROM TBL20001_SENSOR_DATA  WHERE STR_TIMESTAMP BETWEEN %s AND %s" , 
                      "SELECT SENSOR_ID,VALUE,IVALUE,STR_TIMESTAMP FROM TBL20001_SENSOR_DATA  WHERE STR_TIMESTAMP BETWEEN %s AND %s AND SENSOR_ID = %s" , 
                      "SELECT SENSOR_ID,VALUE,IVALUE,STR_TIMESTAMP FROM TBL20001_SENSOR_DATA  WHERE STR_YEAR = %s AND STR_MON = %s AND STR_DAY = %s AND STR_HH = %s",  
                      "SELECT SENSOR_ID,IVALUE FROM TBL20001_SENSOR_DATA  WHERE  SENSOR_ID = %s",
                      "SELECT SENSOR_ID,IVALUE,STR_TIMESTAMP FROM TBL20001_SENSOR_DATA  WHERE SENSOR_ID = %s AND STR_YEAR = %s AND STR_MON = %s AND STR_DAY = %s order by str_timestamp",
                      "SELECT SENSOR_ID,trunc(avg(IVALUE)) IVALUE,STR_YEAR FROM TBL20001_SENSOR_DATA  WHERE SENSOR_ID = %s group by SENSOR_ID,STR_YEAR",
                      "SELECT SENSOR_ID,trunc(avg(IVALUE)) IVALUE,STR_MON  FROM TBL20001_SENSOR_DATA  WHERE SENSOR_ID = %s and STR_YEAR = %s group by SENSOR_ID,STR_MON",
                      "SELECT SENSOR_ID,trunc(avg(IVALUE)) IVALUE,STR_HH  FROM TBL20001_SENSOR_DATA  WHERE SENSOR_ID = %s and STR_YEAR = %s AND STR_MON = %s AND STR_DAY = %s group by SENSOR_ID,STR_HH order by STR_HH",
                      "SELECT SENSOR_ID,IVALUE,STR_TIMESTAMP FROM TBL20001_SENSOR_DATA  WHERE SENSOR_ID = %s AND STR_YEAR = %s AND STR_MON = %s AND STR_DAY = %s and str_timestamp like '%0000' order by str_timestamp",
                      "SELECT userid, pass, area from tbl10001_customer where userid = %s and pass = %s",  
                      "SELECT userid from tbl10001_customer where userid = %s" ] 

    def getQueryStr(self,index):
        self.queryStr = self.queryList[index]
        return self.queryStr

