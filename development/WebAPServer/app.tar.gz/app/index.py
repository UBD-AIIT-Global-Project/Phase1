#!/usr/bin/env python
# -*- coding:utf-8 -*-

from bottle import route, run, default_app, template, request, static_file, os
import sys
from Dao import Dao
import psycopg2


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, 'static')
CSS_DIR = os.path.join(STATIC_DIR, 'css')
JS_DIR = os.path.join(STATIC_DIR, 'js')

@route('/static/css/<filename:path>')
def send_staticCss(filename):
    return static_file(filename, root=STATIC_DIR)

@route('/static/js/<filename:path>')
def send_staticJs(filename):
    return static_file(filename, root=JS_DIR)

@route('/show3')
def men():
    #Get Parameter (uername, men)
    username   = "" 
    sensor_id_ = request.query.sensor_id
    year_      = request.query.year
    mon_       = request.query.mon
    day_       = request.query.day
    area_      = request.query.area

    # Controller =======================================
    if (username == ""):
        username = "Nanashi"
    # View =============================================
    # views/show.tpl Call

    # SENSOR00 TMP
    TMP_ = ''
    d1 = Dao()
    rows  = {}
    rows  = d1.load04(8,sensor_id_,year_,mon_,day_)
    
    for row in rows:
        TMP_ = TMP_ + "%s" %(row[1]) + ","
    TMP_ = TMP_[:-1]
    if  len(TMP_) < 3:
        TMP_ = ",,,,,,,,,,,,,,,,,,,,,,,"

    return template('show3', name=username, TMP_=TMP_, area=area_)



@route('/')
def mainPage():
    # View =============================================
    # views/show.tpl Call

    return template('userLogin')


@route('/title')
def title():
    # Controller =======================================
    #Get Parameter (uername, men)
    sensor_id_ = request.query.sensor_id
    year_      = request.query.year
    mon_       = request.query.mon
    day_       = request.query.day

    # View =============================================
    # views/show.tpl Call
    if (sensor_id_ != ""):
        return template('title', sensor_id=sensor_id_, year=year_, mon=mon_, day=day_)
    return template('title', sensor_id=sensor_id_, year=year_, mon=mon_, day=day_)

@route('/Login')
def title():
    return template('userLogin')

@route('/userMyPage')
def title():
    return template('userMyPage')

@route('/NewAccount')
def title():
    return template('NewAccount')

@route('/mainMenu')
def title():
    return template('mainMenu')

@route('/doRegist', method='POST')
def men():

    #Get Parameter (uername, pass)
    username_    = request.forms.get('user')
    passwd_  = request.forms.get('passwd')
    area_    = '02'
    print (username_)
    print (passwd_)

    #Do Regist Before Check!
    d0 = Dao()
    rows0 = {}
    rows0 = d0.load01(11,username_)

    if len(rows0) > 0:
        return template('mainMenu')
    else:
        #Do Regist!
        cnn = psycopg2.connect("dbname=enpit host=52.33.44.1 user=vagrant password=enpit")
        cur = cnn.cursor()

        print("INSERT INSERT ==========================")
        cur.execute(u"""INSERT INTO TBL10001_CUSTOMER(userid,nickname,pass,area)
                VALUES (%s, %s, %s, %s )""" , (username_, username_, passwd_, area_, ))
        cnn.commit()
        cur.close()
        cnn.close()
        return template('userLogin')

@route('/doLogin', method='POST')
def men():
    #Deafault
    sensor_id_ = '01000001'
    year_      = '2016'
    mon_       = '01'
    day_       = '02'
    sensor_type_ = 'TMP'
    sensor_fix_  = '℃'
    default = "0,"
    area_   = ''
    DEF_ = ",,,,,,,,,,,,,,,,,,,,,,,,"
 

    #Get Parameter (uername, pass)
    username_ = request.forms.get('username')
    passwd_   = request.forms.get('passwd')
    print (username_)
    print (passwd_)

    # ToDo Authory
    d0 = Dao()
    rows0 = {}
    rows0 = d0.load02(10,username_,passwd_)

    if len(rows0) < 1:
       return template('mainMenu')
    else:
        for row in rows0:
            area_ = row[2]
        print(area_)
        if (area_ == "02"):
           sensor_id_ = '01000001' 
        else:
           sensor_id_ = '01000000' 
           day_       = '16'

        # SENSOR DATA
        DATA_ = ''
        d1 = Dao()
        rows  = {}
        rows  = d1.load04(8,sensor_id_,year_,mon_,day_)
        cnt = 24 - len(rows)
        for row in rows:
            DATA_ = DATA_ + "%s" %(row[1]) + ","
        DATA_ = DATA_ + default * cnt
        DATA_ = DATA_[:-1]
        if  len(DATA_) < 3:
            DATA_ = DEF_

        return template('mainPage3', sensor_id=sensor_id_, year=year_, mon=mon_, day=day_,DATA_=DATA_,sensor_type = sensor_type_, sensor_fix = sensor_fix_, area = area_)

# localhost:8080/show  Sample! 
# Query Seting!

@route('/show', method='GET')
def men():
    #Get Parameter (uername, men)
    username = request.query.username
    men = request.query.men

    # Controller =======================================
    if (username == ""):
        username = "Nanashi"

    if men in {"ramen"}:
        menname = "ramen"
    elif men in {"soba"}:
        menname = "soba"
    elif men in {"udon"}:
        menname = "udon"
    else:
        menname = "Error!!"

    # View =============================================
    # views/show.tpl Call

    # SENSOR00 TMP
    TMP_ = ''
    d1 = Dao()
    rows  = {}
    rows  = d1.load01(4,'00000000')
    for row in rows:
        TMP_ = TMP_ + "%s" %(row[1]) + ","
    TMP_ = TMP_[:-1]

    # SENSOR02 SUII
    WL_ = ''
    d2 = Dao()
    rows  = {}
    rows  = d2.load01(4,'00000002')
    for row in rows:
        WL_ = WL_ + "%s" %(row[1]) + ","
    WL_ = WL_[:-1]

    # SENSOR01 SITUDO  
    ST_ = ''
    d3 = Dao()
    rows  = {}
    rows  = d3.load01(4,'00000001')
    for row in rows:
        ST_ = ST_ + "%s" %(row[1]) + ","
    ST_ = ST_[:-1]
    return template('show', name=username, men=menname, TMP_=TMP_, WL_=WL_, ST_=ST_)


# Query Seting! Sqmple!
@route('/showSensor', method='GET')
def men():
    # Controller =======================================
    #Get Parameter (uername, men)
    username   = request.query.username
    sensor_id_ = request.query.sensor_id
    year_      = request.query.year
    mon_       = request.query.mon
    day_       = request.query.day

    # Controller =======================================
    if (username == ""):
        username = "Nanashi"

    # View =============================================
    # views/show.tpl Call
    return template('showSensor', name=username, sensor_id=sensor_id_, year=year_, mon=mon_, day=day_)

@route('/mainPage3')
def mainPage3():

    # Controller =======================================
    #Get Parameter (uername, men)
    sensor_id_ = request.query.sensor_id
    year_      = request.query.year
    mon_       = request.query.mon
    day_       = request.query.day
    area_      = request.query.area


    # View =============================================
    # views/show.tpl Call

    # DEFAULT
    default = "0,"
    sensor_type_ = "---"
    sensor_fix_  = ""
    area_ = '01'

    DEF_ = ",,,,,,,,,,,,,,,,,,,,,,,," 
    if ( sensor_id_ == "" ):
        return template('mainPage3', sensor_id=sensor_id_, year=year_, mon=mon_, day=day_, DATA_=DEF_, sensor_type = sensor_type_, sensor_fix = sensor_fix_, area = area_)
    else:
        # SENSOR TYPE
        
        if (sensor_id_[6:] == '00'):
            area_ = '01'
        else:
            area_ = '02'

        print ("*****" + sensor_id_[6:])
        if (sensor_id_[0:2] == '01'):
            sensor_type_ = "TMP"
            sensor_fix_  = "℃"
        elif (sensor_id_[0:2] == '02'): 
            sensor_type_ = "HUM"
            sensor_fix_  = "%"
        elif (sensor_id_[0:2] == '03'): 
            sensor_type_ = "WATER"
            sensor_fix_  = "cm"
        else:
            sensor_fix_  = " "

        # SENSOR DATA 
        DATA_ = ''
        d1 = Dao()
        rows  = {}
        rows  = d1.load04(8,sensor_id_,year_,mon_,day_)
        cnt = 24 - len(rows)
        for row in rows:
            DATA_ = DATA_ + "%s" %(row[1]) + ","
        DATA_ = DATA_ + default * cnt
        DATA_ = DATA_[:-1]
        if  len(DATA_) < 3:
            DATA_ = DEF_ 
        return template('mainPage3', sensor_id=sensor_id_, year=year_, mon=mon_, day=day_,DATA_=DATA_,sensor_type = sensor_type_, sensor_fix = sensor_fix_, area = area_)

@route('/mainPage2')
def mainPage2():
    # View =============================================
    # views/show.tpl Call

    # DEFAULT
    default = "0,"

    # SENSOR00 TMP
    TMP_ = ''
    d1 = Dao()
    rows  = {}
    rows  = d1.load01(4,'00000000')
    cnt = 12 - len(rows)
    for row in rows:
        TMP_ = TMP_ + "%s" %(row[1]) + ","
    TMP_ = TMP_ + default * cnt
    TMP_ = TMP_[:-1]

    # SENSOR02 SUII
    WL_ = ''
    d2 = Dao()
    rows  = {}
    rows  = d2.load01(4,'00000002')
    cnt = 12 - len(rows)
    for row in rows:
        WL_ = WL_ + "%s" %(row[1]) + ","
    WL_ = WL_ + default * cnt
    WL_ = WL_[:-1]

    # SENSOR01 SITUDO
    ST_ = ''
    d3 = Dao()
    rows  = {}
    rows  = d3.load01(4,'00000001')
    cnt = 12 - len(rows)
    for row in rows:
        ST_ = ST_ + "%s" %(row[1]) + ","
    ST_ = ST_ + default * cnt
    ST_ = ST_[:-1]
    return template('mainPage2', TMP_=TMP_, WL_=WL_, ST_=ST_)
    #return template('mainPage2')

if __name__ == '__main__':
    run(host='localhost', port=8070)
else:
    application = default_app()
