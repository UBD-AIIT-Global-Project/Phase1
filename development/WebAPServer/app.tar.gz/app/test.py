import psycopg2

try:
    #cnn = psycopg2.connect("dbname=enpit host=localhost user=vagrant password=enpit")
    cnn = psycopg2.connect("dbname=enpit host=52.33.44.1 user=vagrant password=enpit")
    #cnn = psycopg2.connect("dbname=enpit host=aiit-cdp-50.xyz user=vagrant password=enpit")
    cur = cnn.cursor()

    print("SELECT SELECT")
    from_id = "00000001" 
    cur.execute("""SELECT SENSOR_ID,VALUE,IVALUE,STR_TIMESTAMP FROM TBL20001_SENSOR_DATA
                WHERE SENSOR_ID = %s""" , (from_id, ))
    rows = cur.fetchall()
    for row in rows:
        #print("%d %s" % (row[0], unicode(row[1],'utf-8')))
        print("%s %s" % (row[0], row[1]))
    cur.close()
    cnn.close()

except (psycopg2.OperationalError) as e:
    print (e)
