import sys
import glob
import os
from Dao import Dao
from ftest import ftest 
import psycopg2


#Directory Read 
SENSOR_PATH = '/var/sensor/02/*.txt'
files = glob.glob(SENSOR_PATH) 
files.sort()

ft = ftest()
for file in files:
    ft.readData(file)
os.system("mv /var/sensor/02/*.txt /var/sensor/BKUP/02/")
print 'complete'

