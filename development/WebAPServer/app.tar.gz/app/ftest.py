# coding: UTF-8
import sys
from Dao import Dao
import psycopg2

class ftest:
    def __init__(self):
        self.ret = ''
        self.queryStr = ''

    #FileRead
    def readData(self,fileName):
        wkStr = fileName.split('_')

        sensorId = wkStr[2] + '000001'
        if (fileName.find('b827eb94b2fd') == -1):
            sensorId = wkStr[2] + '000002' 
        print sensorId

        f = open(fileName)
        lines2 = f.readlines()
        f.close()
        for line in lines2:
            print line,
            self.setData(line,sensorId)
            # DO setData

    #INSERT DATABASE 
    def setData(self,sensorData,sensorID):
        d1 = Dao()
        d1.InsertSensorData(sensorData,sensorID) 
        print '*******'+sensorData
        print 'complete!' 

