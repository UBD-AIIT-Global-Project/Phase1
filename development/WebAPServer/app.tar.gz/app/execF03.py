import sys
import glob
import os
from Dao import Dao
from ftest2 import ftest2 
import psycopg2

#Directory Read 
SENSOR_PATH = '/var/sensor/03/*.txt'
files = glob.glob(SENSOR_PATH) 
files.sort()

ft = ftest2()
for file in files:
    ft.readData(file)
os.system("mv /var/sensor/03/*.txt /var/sensor/BKUP/03/")
print 'complete'

