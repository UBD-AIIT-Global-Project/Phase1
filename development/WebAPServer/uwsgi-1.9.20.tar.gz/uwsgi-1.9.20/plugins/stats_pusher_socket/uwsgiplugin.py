NAME='stats_pusher_socket'

CFLAGS = []
LDFLAGS = []
LIBS = []

GCC_LIST = ['plugin']
