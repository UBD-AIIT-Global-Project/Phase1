NAME='router_memcached'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['router_memcached']
